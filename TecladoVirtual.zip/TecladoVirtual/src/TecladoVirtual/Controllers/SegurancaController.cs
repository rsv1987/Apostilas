﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TecladoVirtual.Controllers
{
    [Route("api/[controller]")]
    public class SegurancaController : Controller
    {
        [HttpGet("BuscarTeclas/{cpfCliente}")]
        public ActionResult BuscarTeclas(long cpfCliente)
        {
            //Cria o array com os 10 algarísmos
            //=================================
            var numeroColecao = new List<byte> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };

            //Embaralha a lista aleatoriamente
            //================================
            var rnd = new Random();
            var query =
                from i in numeroColecao
                let r = rnd.Next()
                orderby r
                select i;

            var listaEmbaralhada = query.ToList();

            //Inicializa a variável de saída
            //==============================
            var teclaColecao = new List<Model.Tecla>();

            //Faz um loop para montar os pares de algarísmos
            //==============================================
            while (listaEmbaralhada.Count > 0)
            {
                //Pega o primeiro e segundo item da lista
                //=======================================
                var n1 = listaEmbaralhada[0];
                var n2 = listaEmbaralhada[1];

                //Remove os itens selecionados da lista
                //=====================================
                listaEmbaralhada.Remove(n1);
                listaEmbaralhada.Remove(n2);

                //Formata os valores de Saída
                //===========================
                teclaColecao.Add(new Model.Tecla()
                {
                    Label = $"{n1} ou {n2}",
                    N1 = n1,
                    N2 = n2
                });
            }

            return Ok(teclaColecao);
        }

        [HttpPost("ValidarSenha/{cpfCliente}")]
        public ActionResult ValidarSenha(long cpfCliente, [FromBody]List<Model.Tecla> teclaColecao)
        {
            //Garante que o usuário tenha informado exatamente 8 dígitos
            //==========================================================
            if (teclaColecao == null || teclaColecao.Count != 8)
            {
                return BadRequest("Por favor, inserir sua senha eletrônica de 8 dígitos.");
            }

            //Recupera a senha decriptada do banco de dados
            //=============================================
            var SenhaDecriptada = ObterSenhaBancoDados(cpfCliente);

            //Abre o loop para comparar dígito a dígito da senha do banco para ver se o usuário
            //enviou a senha correta pelo teclado virtual
            //==================================================================================
            for (int i = 0; i < SenhaDecriptada.Length; i++)
            {
                byte digitoSenha;
                if (!byte.TryParse(SenhaDecriptada.Substring(i, 1), out digitoSenha))
                {
                    return Unauthorized();
                }

                if (digitoSenha != teclaColecao[i].N1 && digitoSenha != teclaColecao[i].N2)
                {
                    return Unauthorized();
                }
            }

            return Ok();
        }

        [HttpPost("InserirUsuario/{cpfCliente}/{senhaEletronica}")]
        public ActionResult InserirUsuario(long cpfCliente, string senhaEletronica)
        {
            //Garante que o usuário tenha informado exatamente 8 dígitos
            //==========================================================
            if (senhaEletronica == null || senhaEletronica.Length != 8)
            {
                return BadRequest("A senha eletrônica precisa conter exatamente 8 dígitos.");
            }

            //Grava o usuário no banco de dados
            //==================================
            IncluirUsuarioBancoDados(cpfCliente, senhaEletronica);

            return Ok();
        }

        private string ObterSenhaBancoDados(long cpfCliente)
        {
            return "21580766";
        }

        private void IncluirUsuarioBancoDados(long cpfCliente, string senhaEletronica)
        {
            
        }
    }
}
