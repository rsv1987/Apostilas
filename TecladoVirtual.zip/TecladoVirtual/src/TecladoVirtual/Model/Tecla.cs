﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TecladoVirtual.Model
{
    public class Tecla
    {
        public string Label { get; set; }
        public byte N1 { get; set; }
        public byte N2 { get; set; }
    }
}
